<!DOCTYPE html>
<html>
<head>
	<title>Phn App| Home</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/animate.min.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">

	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<div align="center" class="header">
		<center><h1>City Farmers LTD</h1>
        <i><h2>Real farming solution</h2></i></center>
	</div>
	<div class="content animated fadeIn">
		<div align="center">
			<h2>Select category from the options</h2>
			<a href="slogin.php"><button class="menu-btn">Staff</button></a>
			<a href="flogin.php"><button class="menu-btn">Farmer</button></a>
			
		</div>
	</div>
</body>
</html>